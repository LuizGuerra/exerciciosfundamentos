
public class e2ExtendedV2{
    public static void main(String args[]){
        System.out.println("\fO maior número de somatórias possíveis são: " + ", do número " + ".");
        int num=1;
        System.out.println("As somatórias do número " + "são: " + somatoria(num));
    }
        public static String somatoria(int num){
        int x, soma1=0, soma2=0;
        int cont=0, contMax=0, numMax=0;
        String somatoria="--- ";
        String somatoriaMax= "--- ";
        for(num=1; num<=50; num++){
            for(x=1;x<=num;x++){
                    for(soma1=x; soma2<=num; soma1++){  
                    soma2=soma2+soma1;
                        if(soma2==num){
                        soma2=0;
                            for(soma1=x; soma2<num; soma1++){
                                soma2=soma2+soma1;
                                somatoria = somatoria + "-" + soma1;
                        }
                        somatoria = somatoria + " --- "; 
                        cont++;
                    }
                }
                soma2=0;
            }
            if(contMax<cont){contMax=cont; numMax=num; somatoriaMax = somatoria;}
            cont=0;
            somatoria= "--- ";
        }
        return somatoria;
    }
}